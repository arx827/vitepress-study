<script lang="ts">
	import 'bootstrap/dist/css/bootstrap.min.css';
</script>

<svelte:head>
	<title>Svelte app</title>
</svelte:head>

<slot />
