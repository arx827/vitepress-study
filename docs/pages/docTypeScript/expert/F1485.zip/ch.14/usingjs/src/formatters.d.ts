export declare function sizeFormatter(thing: string, count: number): void;
export declare function costFormatter(thing: string, cost: number | string ): void;
export declare function writeMessage(message: string): void;