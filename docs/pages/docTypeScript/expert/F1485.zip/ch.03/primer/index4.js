let firstCity;
let secondCity = firstCity || "London";
console.log(`City: ${secondCity}`);