class Product {
    constructor(name, price) {
        this.name = name;
        this.price = price;
    }
    
    toString() {
        return `toString: Name: ${this["name"]}, Price: ${this["price"]}`;
    }
};

let data = {
    hat: new Product("Hat", 100)
};
data["boots"] = new Product("Boots", 100);

Object.keys(data).forEach(key => console.log(`${key} -> ${data[key].toString()}`));
