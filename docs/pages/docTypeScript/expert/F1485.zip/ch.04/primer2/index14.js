class Product {
    constructor(name, price) {
        this.name = name;
        this.price = price;
    }
    
    toString() {
        return `toString: Name: ${this.name}, Price: ${this.price}`;
    }
};

let data = new Map();
data.set("hat", new Product("Hat", 100));
data.set("boots", new Product("Boots", 100));
[...data.keys()].forEach(key => console.log(`${key} -> ${data.get(key).toString()}`));