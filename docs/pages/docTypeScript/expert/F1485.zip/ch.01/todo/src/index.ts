console.clear();
console.log("Adam's Todo List");