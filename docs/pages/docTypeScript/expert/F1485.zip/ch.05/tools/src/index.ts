function printMessage(msg: string): void {
    console.log(`Message: ${msg}`);
}
printMessage("Hello, TypeScript");
// printMessage(100);
printMessage("It is sunny today");